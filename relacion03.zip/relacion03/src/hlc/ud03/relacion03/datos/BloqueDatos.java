package hlc.ud03.relacion03.datos;

public interface BloqueDatos {

  public boolean contieneDato(String nombre);
  
  public String getDato(String nombre);
  
}
