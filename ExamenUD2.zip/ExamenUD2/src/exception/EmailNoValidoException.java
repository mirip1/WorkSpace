package exception;

public class EmailNoValidoException extends IllegalArgumentException {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
