package main;

import util.Bilblioteca;

public class MainApp {

  public static void main(String[] args) {

    String ruta = "Hoa.csv";
    Bilblioteca util = new Bilblioteca();
    util.ficheroCSVToBinario(ruta);
    
    
    
    
  }

}
