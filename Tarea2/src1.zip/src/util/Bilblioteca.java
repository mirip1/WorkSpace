package util;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Bilblioteca {

//  private String url;

  // Constructor
  public Bilblioteca() {

  }

  /**
   * Método que almacena todos los Empleados de un Array o ArrayList en un archivo
   * de texto
   * 
   * @param list lista de empleados
   * @param url  ruta del fichero
   */
  public void ficheroCSVToBinario(String url) {
    // comprobamos que existe el fichero y que es .csv
    File archivo = new File(url);
    String urlNueva = url;
    if (url.endsWith(".csv") && archivo.exists()) {
      // ahora le cambiamos la extension
      urlNueva = urlNueva.replace(".csv", ".dat");
      System.out.println(urlNueva);
      // Primero lee el archivo
      try (BufferedReader br = new BufferedReader(new FileReader(url))) {
        String linea = "";

        // Mientras linea no sea null seguir leyendo
        while ((linea = br.readLine()) != null) {
          System.out.println(linea);
          // Escribimos en el nuevo archivo en binario
          try (ObjectOutputStream oos = new ObjectOutputStream(
              new BufferedOutputStream(new FileOutputStream(urlNueva)))) {
            oos.writeObject(linea);
          } catch (IOException e) {
            e.printStackTrace();
          }
        }
      } catch (IOException e1) {
        // TODO Auto-generated catch block
        e1.printStackTrace();
      }
    }
  }
  
  
  
  
  
  
}
