package main;

import util.Biblioteca;

public class MainApp {

  public static void main(String[] args) {

    String ruta1 = "Hoa.csv";
    String ruta2 = "hola.dat";
    Biblioteca util = new Biblioteca();
//    util.ficheroCSVToBinario(ruta1);
//    util.ficheroBinarioToCSV(ruta1);
    util.ordenarArchivoCSV(ruta1);
    
    
  }

}
