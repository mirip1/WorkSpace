package util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.*;
import java.time.format.DateTimeFormatter;

public class Log {
  private final static String RUTA = "log_csv.txt";
  private LocalDate fecha;
  private LocalTime hora;
  DateTimeFormatter formato;
  
  public static void hacerLog(String metodo, String entrada, String salida) {
  
    
    try (BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA , true))) {
      
        bw.write(logBuilder(metodo, entrada, salida));
        bw.newLine();
      
    } catch (IOException e) {
      e.printStackTrace();
    }
    
  }
  private String logBuilder(String metodo, String entrada, String salida) {
    fecha = LocalDate.now();
    hora = LocalTime.now();
    formato = DateTimeFormatter.ofPattern("HH:mm");
    return "[" + fecha + " " + hora.format(formato) + "] metodo utilizado: "+ metodo + "; fichero entrada: " + entrada + "; fichero salida : " + salida + "\n";
    
  }
  
  
  

}
