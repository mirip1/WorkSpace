package excepciones;

public class FechaVaciaException extends IllegalArgumentException {

  /**
   * 
   */
  private static final long serialVersionUID = 1L;

}
