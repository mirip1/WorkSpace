package main;

import modelos.Cliente;
import views.PantallaPrincipal;

public class MainApp {

  public static void main(String[] args) {
    
    
    PantallaPrincipal ventana = new PantallaPrincipal();
    ventana.setVisible(true);
    
    
    
  }

}
