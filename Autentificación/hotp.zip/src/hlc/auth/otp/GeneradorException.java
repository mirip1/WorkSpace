package hlc.auth.otp;

public class GeneradorException extends RuntimeException {

  public GeneradorException(String message, Throwable cause) {
    super(message, cause);
  }

}
