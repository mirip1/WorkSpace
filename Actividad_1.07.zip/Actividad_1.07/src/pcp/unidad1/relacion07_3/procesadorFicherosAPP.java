package pcp.unidad1.relacion07_3;

public class procesadorFicherosAPP {

  private static final String fichero1 = "informatica.txt";
  private static final String fichero2 = "gerencia.txt";
  private static final String fichero3 = "contabilidad.txt";
  private static final String fichero4 = "comercio.txt";
  private static final String fichero5 = "rrhh.txt";

  public static void main(String[] args) {

    ProcessBuilder pb = new ProcessBuilder("cps", ".c");

    
    
  }

}
