package utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import models.Pelicula;

public class Utils {
  static final String URL = "jdbc:mysql://localhost:3306/sakila";
  static final String USER = "root";
  static final String PASSWORD = "yolo";

  /**
   * metodo quie crea una tabla y la rellena
   */
  public void crearTablaPeliculas() {

    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {

      String comandos = "create table if not exists PeliculasCortas (" + "film_id int primary key,"
          + "title varchar(128)," + "description text(30)," + "release_year year DEFAULT NULL,"
          + "language_id tinyint unsigned NOT NULL," + "length int DEFAULT NULL,"
          + "rating enum('G','PG','PG-13','R','NC-17') DEFAULT 'G'," + " KEY `idx_title` (`title`),"
          + "KEY `idx_fk_language_id` (`language_id`),"
          + "CONSTRAINT `fk_film_language2` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`) ON DELETE RESTRICT ON UPDATE CASCADE"
          + ");";

      try (Statement stmt = con.createStatement()) {

        stmt.execute(comandos);
        System.out.println("Tabla creada exitosamente.");
      } catch (Exception e) {
        e.printStackTrace();

      }
      String rellenar = "INSERT INTO PeliculasCortas"
          + "         SELECT film_id, title, description, release_year, language_id, length, rating"
          + "         FROM film;";
      try (Statement stmt = con.createStatement()) {

        stmt.execute(rellenar);
        System.out.println("Tabla rellenada exitosamente.");
      } catch (Exception e) {
        e.printStackTrace();

      }

    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

  }

  /**
   * metodo que rellena una tabla a partir de un archivo .csv
   */
  public void cargarPeliculas(String ruta) {

    if (!ruta.endsWith(".csv")) {
      throw new IllegalArgumentException();
    }
    
    try (BufferedReader br = new BufferedReader(new FileReader(ruta))) {
      String linea;
      int id = 0;
      String title = "";
      String description = "";
      int release_year = 0;
      int language_id = 0;
      double length = 0;
      String rating = "";

      int cont = 0;
      
      while ((linea = br.readLine()) != null) {

        String[] partes = linea.split(";");
        id = Integer.parseInt(partes[0]);
        title = partes[1];
        description = partes[2];
        release_year = Integer.parseInt(partes[3]);
        language_id = Integer.parseInt(partes[4]);
        length = Double.parseDouble(partes[5]);
        rating = partes[6];

        try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
          String sql = "INSERT INTO PeliculasCortas * VALUES (?, ?, ?, ?, ?, ?, ?)";
          try (PreparedStatement stm = con.prepareStatement(sql)) {
            stm.setInt(1, id);
            stm.setString(2, title);
            stm.setString(3, description);
            stm.setInt(4, release_year);
            stm.setInt(5, language_id);
            stm.setDouble(6, length);
            stm.setString(7, rating);
            
            stm.addBatch(sql);
            cont++;
            
            if(cont == 10) {
              stm.executeBatch();
              stm.clearBatch();
              cont=0;
            }
            

          } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            con.rollback();
          }
          con.commit();
          

        } catch (Exception e) {
          // TODO: handle exception
          e.printStackTrace();
          

        }
        
      }
      

    } catch (Exception e2) {
      // TODO Auto-generated catch block
      e2.printStackTrace();
    }
  }
  
  public void peliculasToFichero(String language, boolean texto) {
    
    List<Pelicula> peliculas = obtenerPeliculasCortas();  // Obtener lista de películas cortas
    List<Pelicula> peliculasFiltradas = new ArrayList<>();

    // Filtrar las películas por el idioma especificado
    for (Pelicula pelicula : peliculas) {
        if (pelicula.getLanguage_id()) {
            peliculasFiltradas.add(pelicula);
        }
    }

    // Crear el archivo en el formato correcto
    if (texto) {
        // Crear un fichero CSV
        String fileName = "peliculas_lang_" + language.toLowerCase() + ".csv";
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            // Escribir encabezado del CSV
            writer.write("Titulo;Año;Duración;Idioma\n");
            for (Pelicula pelicula : peliculasFiltradas) {
                writer.write(pelicula.getId() + ";" + pelicula.getTitle() + ";" + 
                             pelicula.getDescription() + ";" + pelicula.getRelease_year() + ";" + 
                             pelicula.getLanguage_id() + ";" + 
                             pelicula.getLength() + ";" + 
                             pelicula.getRating() +"\n");
            }
            System.out.println("Archivo de texto creado: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    } else {
        // Crear un fichero binario
        String fileName = "peliculas_lang_" + language.toLowerCase() + ".dat";
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            for (Pelicula pelicula : peliculasFiltradas) {
                oos.writeObject(pelicula);
            }
            System.out.println("Archivo binario creado: " + fileName);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
      
      
      
    }
    
    
  }
}
  public List<Pelicula> obtenerPeliculasCortas() {
    List<Pelicula> peliculas = new ArrayList<>();
    peliculas.add(new Pelicula("Pelicula 1", 2001, 90, "English"));
    peliculas.add(new Pelicula("Pelicula 2", 2002, 85, "French"));
    peliculas.add(new Pelicula("Pelicula 3", 2003, 80, "English"));
    peliculas.add(new Pelicula("Pelicula 4", 2004, 70, "Spanish"));
    peliculas.add(new Pelicula("Pelicula 5", 2005, 65, "French"));
    return peliculas;
}

}
