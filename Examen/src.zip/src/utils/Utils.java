package utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Utils {
  static final String URL = "jdbc:mysql://localhost:3306/sakila";
  static final String USER = "root";
  static final String PASSWORD = "yolo";
  
  private void crearTablaPeliculas() {
    
    
    try (Connection con = DriverManager.getConnection(URL, USER, PASSWORD)) {
      
      String comandos ="create table PeliculasCortas ("
          + "film_id int primary key,"
          + "title varchar(128),"
          + "description text(30),"
          + "release_year year DEFAULT NULL,"
          + "language_id tinyint unsigned NOT NULL,"
          + "length int DEFAULT NULL,"
          + "rating enum('G','PG','PG-13','R','NC-17') DEFAULT 'G',"
          + " KEY `idx_title` (`title`),"
          + "KEY `idx_fk_language_id` (`language_id`),"
          + "CONSTRAINT `fk_film_language2` FOREIGN KEY (`language_id`) REFERENCES `language` (`language_id`) ON DELETE RESTRICT ON UPDATE CASCADE"
          + ");";
      
      con.createStatement();

      
      
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
  }
  
  

}
