package main;

import java.io.IOException;
import java.util.ArrayList;

import org.hibernate.Session;

import conexion.Utils;
import models.Superusuario;

public class Main {
  
  
  
  public static void main(String[] args) {
    Session session = Utils.getSession();

    session.getTransaction().begin();
    
    try {
      //Metemos los usuarios
      ArrayList<Superusuario> admins = Utils.leerFicheros("Alumnado_nuevo.txt");
      for (Superusuario usu : admins) {
        usu = session.merge(usu);
        
      }
      session.getTransaction().commit();
      
      // Cierro Session y SessionFactory
      Utils.closeSession();
      
      
      
      
      
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }
    
    
    
    
    
  }

}
