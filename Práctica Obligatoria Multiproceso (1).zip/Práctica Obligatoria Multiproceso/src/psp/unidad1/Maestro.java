package psp.unidad1;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.Future;

public class Maestro {

  public static void main(String[] args) {
    int numNucleos = 0;

    if (!(args.length >= 2)) {
      System.out.println("Se le deben pasar almenos 2 parametros");
      return;
    }
    if (args.length > 2) {
      numNucleos = Integer.parseInt(args[2]);
    } else {
      numNucleos = Runtime.getRuntime().availableProcessors();
    }

    int num1 = Integer.parseInt(args[0]);
    int num2 = Integer.parseInt(args[1]);

    if (num1 > num2) {
      int auxiliar = num2;
      num2 = num1;
      num1 = auxiliar;

    }

    int rango = num2 - num1 + 1;
    List<Integer> primosTotales = Collections.synchronizedList(new ArrayList<>());

    try {
      ProcessBuilder pb = new ProcessBuilder("java", "-jar", "Esclavo.jar");
      Process process = pb.start();

      // Llamar al proceso hijo
      try (PrintWriter writer = new PrintWriter(new OutputStreamWriter(process.getOutputStream()))) {
        writer.println(num1);
        writer.println(num2);
        writer.flush();
      }

      try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
        String line;
        while ((line = reader.readLine()) != null) {
          System.out.println(line);
        }
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

  }

}
