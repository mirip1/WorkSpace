package mainApp;

import java.util.ArrayList;
import java.util.List;

import models.Empleado;
import utils.UtilsFicheroArray;

public class MainApp {

  static final String URL1 = "fichero.txt";
  static final String URL2 = "fichero2.txt";

  public static void main(String[] args) {
    
    UtilsFicheroArray util = new UtilsFicheroArray();
//    util.leer_Empleados(URL1);
//    util.leerFichero(URL1).forEach(System.out::println);
    
    List<Empleado> empleados = new ArrayList();
    empleados = util.leerFichero(URL1);
    
    for (Empleado i: empleados) {
     System.out.println(i);
    }
    
    
    util.toArchivoTexto(util.leerFichero(URL1), URL2);
    
    

    
  }

}
