package models;

public class Empleado {
  
  //Empresa del empleado
  private String empresa;
  
  //edad del empleado
  private int edad;
  
  //numero de empleados a ccargo
  private int numeroEmpleados;
  
  //constructor
  public Empleado(String empresa, int edad, int numeroEmpleados) {
    super();
    this.empresa = empresa;
    this.edad = edad;
    this.numeroEmpleados = numeroEmpleados;
  }
  
  public Empleado() {
    
  }

  /**
   * @return the empresa
   */
  public String getEmpresa() {
    return empresa;
  }

  /**
   * @param empresa the empresa to set
   */
  public void setEmpresa(String empresa) {
    this.empresa = empresa;
  }

  /**
   * @return the edad
   */
  public int getEdad() {
    return edad;
  }

  /**
   * @param edad the edad to set
   */
  public void setEdad(int edad) {
    this.edad = edad;
  }

  /**
   * @return the numeroEmpleados
   */
  public int getNumeroEmpleados() {
    return numeroEmpleados;
  }

  /**
   * @param numeroEmpleados the numeroEmpleados to set
   */
  public void setNumeroEmpleados(int numeroEmpleados) {
    this.numeroEmpleados = numeroEmpleados;
  }

  @Override
  public String toString() {
    return "Empresa: " + empresa + "\n Edad" + edad + "\n Numero de Empleados: " + numeroEmpleados ;
  }
  
  
  
  

}
