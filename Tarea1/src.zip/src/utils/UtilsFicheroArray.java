package utils;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

import models.Empleado;

public class UtilsFicheroArray {
  private String url;
  private ArrayList<Empleado> lista;

  public UtilsFicheroArray(String url) {
    super();
    if (url != null) {
      this.url = url;
      this.lista = new ArrayList<>();
    }else {
      System.out.println("la url no puede ser null");
    }
  }

  // Lee y guarda el fichero en la lista
  public void leerFichero() {
    BufferedReader br = null;
    
    try  {
      br = new BufferedReader(new FileReader(url));
      System.out.println(br.readLine());
      String linea;
      
      //mientras linea no sea null seguir leyendo
      while ((linea = br.readLine()) != null) {
        
        String[] partes = linea.replaceAll("\"", "").split(",");
        Empleado e = new Empleado(partes[0], Integer.parseInt(partes[1]), Integer.parseInt(partes[2]));
        
        
        
      }
      
    } catch (FileNotFoundException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } catch (IOException e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    } finally {
      if (br != null)
        try {
          br.close ();
        } catch (IOException e) {
          // TODO Auto-generated catch block
          e.printStackTrace();
        }
    }

  }

  /**
   * @return the url
   */
  public String getUrl() {
    return url;
  }

  /**
   * @return the lista
   */
  public ArrayList<Empleado> getLista() {
    return lista;
  }

}
