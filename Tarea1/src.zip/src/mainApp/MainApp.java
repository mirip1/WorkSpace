package mainApp;

import utils.UtilsFicheroArray;

public class MainApp {

  public static void main(String[] args) {
    UtilsFicheroArray util = new UtilsFicheroArray("fichero.txt");
    util.leerFichero();

  }

}
