import java.util.Random;
import java.util.Scanner;
import es.iespablopicasso.programacion.bloque02.figuras.Paralelogramo;

public class ParalelogramosApp {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("EXAMEN DE Miguel_Velasco_Fernandez");
    System.out.println("Propiedades de los palalelogramos");
    //Pedimos los lados por pantalla
    //horizontal
    System.out.println("Introduzca la longitud de los lados horizontales: ");
    double longitudHorizontal = Double.parseDouble(scan.nextLine());
    
    //Vertical pedimos el valor minimo y maximo
    System.out.println("Introduzca el límite mínimo de los posibles valores de la longitud del lado vertical: ");
    double minimo = Double.parseDouble(scan.nextLine());
    
    System.out.println("Introduzca el límite máximo de los posibles valores de la longitud del lado vertical: ");
    double maximo = Double.parseDouble(scan.nextLine());
    
    //Obtenemos un numero aleatorio de entre los dos anteriores
    Random numRandom1 = new Random();
    double longitudVertical=numRandom1.nextDouble(minimo, maximo);
    
    System.out.println("La longitud del lado vertical obtenida al azar es: " + longitudVertical);
    
    //creamos el paralelogramo con los datos que tenemos
    Paralelogramo paralelogramo1 = new Paralelogramo(longitudHorizontal, longitudVertical);
    
    
    //Imprimimos y Calculamos el área del perimetro
    
    String areaPerimetro = paralelogramo1.getAreaPerimetro();
    System.out.println("El area del paralelogramo es:" + areaPerimetro.substring(0, 18)+" y el perimetro: "+areaPerimetro.substring(19, 36) );
    
    
  
    
  }
}
