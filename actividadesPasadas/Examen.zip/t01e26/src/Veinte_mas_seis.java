import java.util.Scanner;

public class Veinte_mas_seis {

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    String string = parseString.String(scan nextLine()); 
    
  }
      
}
