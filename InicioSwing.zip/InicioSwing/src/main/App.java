package main;

import views.PantallaPrincipal;

public class App {

  public static void main(String[] args) {
    PantallaPrincipal frame = new PantallaPrincipal();
    frame.setVisible(true);
    
  }

}
