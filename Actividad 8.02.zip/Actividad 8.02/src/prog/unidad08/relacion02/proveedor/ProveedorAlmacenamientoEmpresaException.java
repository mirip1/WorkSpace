package prog.unidad08.relacion02.proveedor;

public class ProveedorAlmacenamientoEmpresaException extends RuntimeException{

}
